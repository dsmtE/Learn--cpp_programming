# Recherche de chemin et simplification de graphes pour les données OSM

Ce projet utilise les données d'OpenStreetMap (OSM) pour en construire une représentation sous forme de graphe afin de pouvoir effectuer des recherches de chemin sur ce graphe. Le projet inclut également des fonctions de simplification du graphe pour réduire sa complexité tout en préservant les caractéristiques essentielles du graphe.

Enfin, une interface de visualisation utilisant la bibliothèque **raylib** est incluse pour permettre de visualiser le graphe et les chemins trouvés.

Il est possible de télécharger des données OSM via plusieurs méthodes mais il est possible de passer par ce lien https://www.openstreetmap.org/export pour télécharger une zone d'intérêt au format .osm.

### Utilisation basée sur les commandes

Le projet est organisé autour de plusieurs commandes qui peuvent être exécutées pour effectuer différentes opérations sur les graphes.

- `extract`: Cette commande permet d'extraire les données OSM d'un fichier .osm et de construire un graphe à partir de ces données. Le graphe est ensuite sauvegardé dans un format binaire pour une utilisation ultérieure.

- `simplify`: Cette commande prend un graphe extrait précédemment et applique plusieurs techniques de simplification pour réduire le nombre de nœuds et d'arêtes tout en préservant la structure générale du graphe.

- `visualize`: Cette commande permet d'ouvrir une fenêtre de visualisation pour afficher le graphe et les chemins trouvés. Elle peut être utilisée pour visualiser les résultats de la simplification ou pour explorer le graphe de manière interactive.

- `visualizeAndProcess`: Cette commande combine les fonctionnalités des trois commandes précédentes en extrayant les données OSM, en simplifiant le graphe et en visualisant le résultat dans une seule exécution.

Vous pourrez trouver les détails d'utilisation de chaque commande en essayant de les exécuter avec l'option `--help` pour obtenir des informations sur les arguments et les options disponibles.

Un fichier `.vscode/launcher.json` ainsi qu'un fichier OSM de test sont inclus dans le projet pour faciliter l'exécution de ces commandes directement depuis Visual Studio Code.

### Structure de données

Il y a deux structures de graphe différentes : `WeightedGraph` qui est une structure de graphe générique avec des poids sur les arêtes, et `PositionedGraph` qui est une structure de graphe spécifique pour les données OSM avec des positions géographiques (et un ID) associées à chaque nœud. Les fonctions de simplification du graphe sont principalement conçues pour fonctionner avec la structure `PositionedGraph`, tandis que les fonctions de recherche de chemin peuvent être utilisées avec les deux structures de graphe.

### Lecture de données OSM

La lecture des données OSM est effectuée à l'aide de la bibliothèque `pugixml` pour parser les fichiers XML au format .osm. Les nœuds et les chemins sont extraits du fichier et utilisés pour construire le graphe. Les nœuds sont stockés avec leurs positions géographiques, tandis que les chemins sont utilisés pour créer les arêtes du graphe.

Le graphe est ensuite sauvegardé dans un format binaire en utilisant la sérialisation de la librairie `cereal` pour permettre une lecture rapide lors des étapes de simplification et de visualisation sans avoir à reparser le fichier XML à chaque fois.

### Simplification du graphe

La simplification du graphe est réalisée à l'aide de plusieurs techniques différentes, chacune visant à réduire le nombre de nœuds et d'arêtes tout en préservant la structure générale du graphe. Ces techniques incluent :

- **Suppression des nœuds de degré 2** : Les nœuds qui ont exactement deux voisins sont supprimés en connectant directement leurs voisins entre eux, à condition que l'angle formé par les trois nœuds soit inférieur à un certain seuil.
- **Regroupement des nœuds par proximité et profondeur de connexion** : Les nœuds qui sont proches les uns des autres et qui ont des voisins similaires dans un certain rayon de connexion sont regroupés ensemble pour former un seul nœud représentatif.
- **Suppression des petites arêtes terminales** : Les nœuds qui ont un seul voisin et qui sont proches de ce voisin sont supprimés pour éliminer les petites branches du graphe.
- **Conservation de la plus grande composante connexe** : Seule la plus grande composante connexe du graphe est conservée, les autres nœuds et arêtes sont supprimés.


